class MyColors {
  static int header01 = 0xff228B22;
  static int primary = 0xFF00693E;
  static int purple01 = 0xff918fa5;
  static int purple02 = 0xFF8EA58F;
  static int yellow01 = 0xffeaa63b;
  static int yellow02 = 0xfff29b2b;
  static int bg = 0xfff5f3fe;
  static int bg01 = 0xff50C878;
  static int bg02 = 0xffACE1AF;
  static int bg03 = 0xFFC1E6C3;
  static int text01 = 0xff50C878;
  static int grey01 = 0xffe9ebf0;
  static int grey02 = 0xFF86A591;
  static int kprimaryButtonsColor = 0xFFFF9900;
  static int ksecondaryButtonCcolor = 0xFFFFB000;
  static int kliteblueButtonCcolor = 0xFFFFC851;
  static int ksecondaryColor = 0xFFF9E5C2;
}
