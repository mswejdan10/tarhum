package com.example.medicare

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
